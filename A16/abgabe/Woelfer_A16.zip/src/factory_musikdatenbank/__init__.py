from src.factory_musikdatenbank.MusikdatenbankFabrik import *
from src.factory_musikdatenbank.MusikdatenbankMockupFabrik import *
from src.factory_musikdatenbank.MusikdatenbankFileFabrik import *
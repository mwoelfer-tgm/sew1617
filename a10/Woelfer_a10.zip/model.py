class Model:
    def __init__(self):
        self.points = []
        self.closes = False
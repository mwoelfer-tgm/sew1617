Project Modules
===============
   :Author: Martin Woelfer
   :Status: Finished
   :Version: 1.0
   :Date: 2017-04-06
   :Organization: TGM Wien
   :Summary: Creates a program used for flexible archiving which is also easily extentedable due to the strategy-pattern
   
.. toctree::
   :maxdepth: 4

   src
